package org.apache.poi.xssf.usermodel.examples;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.InvalidPropertiesFormatException;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @see #main
 * @author H
 */
public final class XSSFReadWrite {

	/**
	 * creates an {@link XSSFWorkbook} the specified OS filename.
	 */
	private static XSSFWorkbook readFile(String filename) throws IOException {
		return new XSSFWorkbook(new FileInputStream(filename));
	}

	/**
	 * Method main
	 */

	public static Logger log = Logger.getLogger(XSSFReadWrite.class);

	public static void main(String[] args) {

		if (args.length < 9) {
			System.err.println("At least 15 argument expected");
			return;
		}

		log.log(Level.INFO, "***************");
		String fileName1 = args[0];
		String sheetName1 = args[1];
		Integer columnPosition1 = new Integer(args[2]);

		String fileName2 = args[3];
		String sheetName2 = args[4];
		Integer columnPosition2 = new Integer(args[5]);

		String fileName = args[6];

		String sheetName3 = args[7];
		Integer columnPosition3 = new Integer(args[8]);

		String sheetName4 = args[9];
		Integer columnPosition4 = new Integer(args[10]);

		String sheetName5 = args[11];
		Integer columnPosition5 = new Integer(args[12]);

		String sheetName6 = args[13];
		Integer columnPosition6 = new Integer(args[14]);

		try {

			if (args.length == 15) {
				ArrayList<String> stringsToTolerate = loadToleratedStrings(fileName);

				log.log(Level.INFO,
						"*** 1-	Verification of Offering Info *****");

				ArrayList<String> values1 = extractValuesFromExcelColumn(
						fileName1, sheetName1, columnPosition1);
				ArrayList<String> values3 = extractValuesFromExcelColumn(
						fileName1, sheetName3, columnPosition3);
				List<String> newList = new ArrayList<String>(values1);
				newList.addAll(values3);
				HashSet<String> hs = new HashSet<String>();
				hs.addAll(newList);
				newList.clear();
				newList.addAll(hs);
				ArrayList<String> values2 = extractValuesFromExcelColumn(
						fileName2, sheetName2, columnPosition2);

				ArrayList<String> comparisonResult1 = compareLists(newList,
						values2, stringsToTolerate);
				log.log(Level.INFO,
						"****DIfference from file one to two one in args list********");
				for (String val : comparisonResult1) {

					log.log(Level.TRACE, val);
				}

				ArrayList<String> comparisonResult2 = compareLists(values2,
						newList, stringsToTolerate);
				log.log(Level.INFO,
						"*****DIfference from file two to file one in args list********");
				for (String val : comparisonResult2) {

					log.log(Level.TRACE, val);

				}

				log.log(Level.INFO,
						"*** END/1-	Verification of Offering Info *****");
				log.log(Level.INFO, "*********************************************************************************************");
				/***********************************************************/
				log.log(Level.INFO, "*** 2-	Verifications of Price Plans *****");

				ArrayList<String> valuesOne = extractValuesFromExcelColumn(
						fileName1, sheetName5, columnPosition5);
				ArrayList<String> valuesThree = extractValuesFromExcelColumn(
						fileName1, sheetName6, columnPosition6);
				List<String> newList1 = new ArrayList<String>(valuesOne);
				newList1.addAll(valuesThree);
				HashSet<String> hashSet = new HashSet<String>();
				hashSet.addAll(newList1);
				newList1.clear();
				newList1.addAll(hashSet);
				ArrayList<String> valuesTwo = extractValuesFromExcelColumn(
						fileName2, sheetName4, columnPosition4);

				ArrayList<String> comparisonResultOne = compareLists(newList1,
						valuesTwo, stringsToTolerate);
				log.log(Level.INFO,
						"****DIfference from file one to two one in args list********");
				for (String val : comparisonResultOne) {

					log.log(Level.TRACE, val);
				}

				ArrayList<String> comparisonResultTwo = compareLists(valuesTwo,
						newList1, stringsToTolerate);
				log.log(Level.INFO,
						"*****DIfference from file two to file one in args list********");
				for (String val : comparisonResultTwo) {

					log.log(Level.TRACE, val);

				}

				log.log(Level.INFO,
						"*** END/2-	Verifications of Price Plans *****");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		log.log(Level.INFO, "/***************");
	}

	protected static ArrayList<String> extractValuesFromExcelColumn(
			String fileName, String sheetName, Integer columnPosition)
			throws IOException {
		ArrayList<String> values = new ArrayList<String>();
		XSSFWorkbook wb = XSSFReadWrite.readFile(fileName);
		XSSFSheet sheet = wb.getSheet(sheetName);
		int rows = sheet.getPhysicalNumberOfRows();
		for (int r = 0; r < rows; r++) {
			XSSFRow row = sheet.getRow(r);
			if (row == null) {
				continue;
			}

			XSSFCell cell = row.getCell(columnPosition - 1);
			String value = null;
			if (cell != null) {
				value = cell.toString();
				if (!value.trim().isEmpty()) {
					values.add(value);
				}
			}
		}
		return values;
	}

	/**
	 * This method compares the first passed array to the second one and not the
	 * opposite
	 */
	protected static ArrayList<String> compareLists(List<String> values1,
			List<String> values2, ArrayList<String> stringsToTolerate) {
		ArrayList<String> comparisonResult = new ArrayList<String>();
		for (String val : values1) {
			if (!values2.contains(val) && !stringsToTolerate.contains(val)) {
				comparisonResult.add(val);
			}
		}
		return comparisonResult;
	}

	/**
	 * This method compares the first passed array to the second one and not the
	 * opposite
	 */
	protected static ArrayList<String> loadToleratedStrings(String fileName) {
		ArrayList<String> toleratedResult = new ArrayList<String>();
		Properties properties = new Properties();
		try {
			InputStream xmlStream = new FileInputStream(fileName);
			properties.loadFromXML(xmlStream);
		} catch (InvalidPropertiesFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (Object obj : properties.values()) {
			toleratedResult.add(obj.toString());
		}
		return toleratedResult;

	}
}